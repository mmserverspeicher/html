import xbmcaddon

MainBase = 'https://bit.ly/2Owqto8'
addon = xbmcaddon.Addon('plugin.video.wagasworld')