class LoginFailedException(Exception):
	pass
