# plugin.video.zattoo_hiq
Play Live TV and recorded shows from Zattoo.

Support: https://www.kodinerds.net/index.php/Thread/55690-Aus-ZattooBoxExtBeta-wird-ZattooHiQ/

Plugin für kodi 18
---
